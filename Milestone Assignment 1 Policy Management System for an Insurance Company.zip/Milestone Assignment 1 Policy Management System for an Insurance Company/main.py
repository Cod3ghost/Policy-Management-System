from policyholder import Policyholder
from product import Product
from payment import Payment

def create_policyholder(counter):
    policyholder_id = input(f"Enter policyholder {counter} ID: ")
    name = input(f"Enter policyholder {counter} name: ")
    return Policyholder(policyholder_id=policyholder_id, name=name)

def create_product(counter):
    product_id = input(f"Enter product {counter} ID: ")
    name = input(f"Enter product {counter} name: ")
    return Product(product_id=product_id, name=name)

def process_payment(policyholder):
    amount = float(input(f"Enter payment amount for {policyholder.name}: "))
    payment = Payment(policyholder=policyholder, amount=amount)
    payment.process_payment()
    return payment

def display_details(policyholder, payment):
    print("\nPolicyholder Details:")
    print(policyholder.display_details())
    print("\nPayment Details:")
    print(payment.display_payment_details())

def main():
    # Create products dynamically
    product1 = create_product(1)
    product2 = create_product(2)

    # Create policyholders dynamically
    policyholder1 = create_policyholder(1)
    policyholder2 = create_policyholder(2)

    # Register products for policyholders
    policyholder1.register(product1)
    policyholder2.register(product2)

    # Process payments for each policyholder dynamically
    payment1 = process_payment(policyholder1)
    payment2 = process_payment(policyholder2)

    # Display the policyholders' and payment details
    display_details(policyholder1, payment1)
    display_details(policyholder2, payment2)

if __name__ == "__main__":
    main()
