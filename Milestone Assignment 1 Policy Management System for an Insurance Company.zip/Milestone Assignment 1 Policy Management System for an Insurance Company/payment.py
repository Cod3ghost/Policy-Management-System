class Payment:
    def __init__(self, policyholder, amount, status="Pending"):
        self.policyholder = policyholder
        self.amount = amount
        self.status = status

    def process_payment(self):
        self.status = "Paid"

    def send_reminder(self):
        return f"Reminder: Payment of {self.amount} is due for {self.policyholder.name}."

    def apply_penalty(self, penalty_amount):
        self.amount += penalty_amount

    def display_payment_details(self):
        return {
            "Policyholder": self.policyholder.name,
            "Amount": self.amount,
            "Status": self.status
        }
