class Policyholder:
    def __init__(self, policyholder_id, name, status="Active"):
        self.policyholder_id = policyholder_id
        self.name = name
        self.status = status
        self.products = []

    def register(self, product):
        self.products.append(product)

    def suspend(self):
        self.status = "Suspended"

    def reactivate(self):
        self.status = "Active"

    def display_details(self):
        product_names = [product.name for product in self.products]
        return {
            "Policyholder ID": self.policyholder_id,
            "Name": self.name,
            "Status": self.status,
            "Products": product_names
        }
