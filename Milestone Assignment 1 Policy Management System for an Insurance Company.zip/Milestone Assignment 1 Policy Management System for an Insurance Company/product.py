class Product:
    def __init__(self, product_id, name, status="Available"):
        self.product_id = product_id
        self.name = name
        self.status = status

    def update_product(self, new_name):
        self.name = new_name

    def suspend_product(self):
        self.status = "Suspended"

    def reactivate_product(self):
        self.status = "Available"

    def display_product(self):
        return {
            "Product ID": self.product_id,
            "Name": self.name,
            "Status": self.status
        }
